#!/bin/bash

export DISPLAY=:0
/usr/bin/python3 /home/jetson/Novius_Projects_Development/MVIS_Master/Mvis_Jetson_Nano_Project/railway_wheel_motion.py
