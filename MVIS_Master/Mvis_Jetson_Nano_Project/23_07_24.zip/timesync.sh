#!/bin/bash
sudo /usr/sbin/ntpdate -u 192.168.1.15
